

public class Login {
    
    String username;
    String password;
    String phoneNumber;
    
    // Method to check if username is valid
    public boolean checkUserName(String username){
        // Check if username has _ and is 5 characters or less
       return username.contains("_") && username.length() <= 5;
    }
    
   // Method to check if password is strong enough 
    public boolean checkPasswordComplexity(String password){
        // Variable to check password rules   
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        
           // Loop through every character in the password
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
               
            // Check if character is a capital letter
            if (Character.isUpperCase(c)){
                hasCapital = true;
            }
            // Check if character is a number 
            if (Character.isDigit(c)){
                hasNumber = true;
            }
            
            // Check if character is not a letter or number (special character)
            if (!Character.isLetterOrDigit(c)){
                hasSpecial = true;
            }
        }
        
        
        // Check if password is at least 8 characters long and meet all requirements
        return password.length() >= 8 && hasCapital && hasNumber && hasCapital;
    }
       // Method to check if phone number is valid
    public boolean checkCellPhoneNumber(String phone){
        
        // Check if number starts with +27 and is 12 character or less
        return phone.startsWith("+27") && phone.length() <= 12;
    }
       // Method to register a new user 
    public String registerUser(String username,String password,String phoneNumber){
        
        // First check if username is valid
        if(!checkUserName(username)){
            
            // Return error message if username is not correct
            return "Username is not correctly formatted; please ensure that the username contains an"
                       + "underscore and is no more than five character in length";
        }
        // Check if phone number is valid
        if (!checkPasswordComplexity(password) ){
            // Return error message if password is not correct 
           return "Password is not correctly formatted; please ensure that the password contains at"
                       + "less eight characters,a capital letter,a number,and a special character.";
        }
        // Check if phone number is valid
        if (!checkCellPhoneNumber(phoneNumber)){
            // Return error message if phone number is not correct
           return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        // If all checks pass, save the information to the class variables 
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
         
        // Return success message 
        return "User registered successfully.";
    }
    // Method to check if user can login 
    public boolean loginUser(String username,String password){
        // Check if entered details match the saved details
        return this.username.equals(username) && this.password.equals(password);
    }
    // Method to check if user can login
    public String returnloginStatus(boolean success){
        // Check if login was successful
        if (success){
            // Return welcome message if login is correct
            return "Welcome " + username + "it is great to see you again.";
        } else {
            // Return error message if username or password is wrong
            return "Username or password incorrect, please try again.";
        }
    }
}

       
       
               
           
           
           
       
   
    
    
    

   