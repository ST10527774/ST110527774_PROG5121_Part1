/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author User
 */
public class LoginTest {
    // Create an object to use methods from login class
    Login login = new Login();
    // -------- Username Tests --------
    
   //Test to check if a valid username is accepted 
    @Test
    void testValidUsername() {
       //ssertTrue(login.checkUserName("ab_cd"));
       boolean result = login.checkUserName("Kyl_1");
       assertTrue(result);
    }

    @Test
    void testInvalidUsername_NoUnderscore() {
        assertFalse(login.checkUserName("Itu"));
    }

    @Test
    void testInvalidUsername_TooLong() {
        assertFalse(login.checkUserName("Itumeleng lolwana"));
    }

    // -------- Password Tests --------
    @Test
    void testValidPassword() {
        assertTrue(login.checkPasswordComplexity("Alulutho*2!"));
    }
    
    @Test
    void testInvalidPassword_NoCapital() {
        assertFalse(login.checkPasswordComplexity("alu*2!"));
    }

    @Test
    void testInvalidPassword_NoNumber() {
        assertFalse(login.checkPasswordComplexity("Password!"));
    }

    @Test
    void testInvalidPassword_NoSpecialChar() {
        assertFalse(login.checkPasswordComplexity("Password1"));
    }

    @Test
    void testInvalidPassword_TooShort() {
        assertFalse(login.checkPasswordComplexity("lolwana!"));
    }

    // -------- Phone Number Tests --------
    @Test
    void testValidPhoneNumber() {
        assertTrue(login.checkCellPhoneNumber("+27721728831"));
    }

    @Test
    void testInvalidPhoneNumber_NoCountryCode() {
        assertFalse(login.checkCellPhoneNumber("0123456789"));
    }

    @Test
    void testInvalidPhoneNumber_TooLong() {
        assertFalse(login.checkCellPhoneNumber("+271728831"));
    }

    // -------- Registration Tests --------
    @Test
    void testSuccessfulRegistration() {
        String result = login.registerUser("ab_cd", "Passw0rd!", "+27123456789");
        assertEquals("User registered successfully.", result);
    }

    @Test
    void testRegistration_InvalidUsername() {
        //Try to register with a username that is not valid
        String result = login.registerUser("abcde", "Passw0rd!", "+27123456789");
        // Check if the error message about username appears
        assertTrue(result.contains("Username is not correctly formatted"));
    }

    @Test
    void testRegistration_InvalidPassword() {
        // Try to register with a password that is not valid 
        String result = login.registerUser("ab_cd", "password", "+27123456789");
        // Check error message about password appears
        assertTrue(result.contains("Password is not correctly formatted"));
    }

    @Test
    void testRegistration_InvalidPhone() {
        // Try to register with a password that is not valid 
        String result = login.registerUser("Kyl_1", "Passw0rd!", "123456");
        // Check if the error message about phone number appears
        assertTrue(result.contains("Cell phone number incorrectly formatted"));
    }

    // -------- Login Tests --------
    @Test
    void testLoginSuccess() {
        // First register a user correctly 
        login.registerUser("ab_cd", "Passw0rd!", "+27123456789");
        // Check if login fails when password is wrong 
        assertTrue(login.loginUser("ab_cd", "Passw0rd!"));
    }

    @Test
    void testLoginFailure() {
        login.registerUser("ab_cd", "Passw0rd!", "+27123456789");
        assertFalse(login.loginUser("ab_cd", "wrongPass"));
    }

    // -------- Login Status Tests --------
    @Test
    void testReturnLoginStatus_Success() {
        // First register a user 
        login.registerUser("ab_cd", "Passw0rd!", "+27123456789");
        // Get the message when login is successful 
        String message = login.returnloginStatus(true);
        // Check if the message contains the word "Welcome"
        assertTrue(message.contains("Welcome"));
    }

    @Test
    void testReturnLoginStatus_Failure() {
        // Check if the message when login fails
        String message = login.returnloginStatus(false);
        // Check if the message matches exactly the error text
        assertEquals("Username or password incorrect, please try again.", message);
    }
}
